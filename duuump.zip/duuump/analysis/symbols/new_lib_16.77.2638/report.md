# br64 16.77.2638 inferred symbol report

- total inferred/extra entries: 47430
- strong inferred entries: 12378
- actual named entries already visible in new dump: 204

## Inference kinds

- address_neighborhood: 32953
- calls_known_cluster: 8483
- single_known_caller_helper: 2780
- string_reference: 1895
- thunk_to_known_function: 1115
- actual_named_in_new_dump: 204

## Largest new/unknown clusters

### sub_6EC064..sub_8B5B88 (3364 funcs)
- modules: [('ay::obfuscated_data<T>', 419), ('Noesis', 185), ('OUTLINED', 138), ('thunk_to::NoesisApp::EventTriggerBase', 81), ('Noesis::TypePropertyFunction<T>::helper_for_Noesis::TypePropertyFunction_Gui::CMapTutorialViewModel_', 73), ('Gui::CMapViewModel::helper_for_Gui::CMapViewModel::StaticFillClassType_Noesis', 72)]
- kinds: [('calls_known_cluster', 2010), ('single_known_caller_helper', 866), ('thunk_to_known_function', 347), ('string_reference', 141)]
- between: `anonymous namespace'::IsCheckObjectVehicle(CObject *,CPhysical *) -> Gui::ParseMapStaticConfig(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::allocator,n...
- strings: ['cannot use value() with ', 'Assertion failed!', 'Boxed<', 'Ptr<%s>', 'Verify failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/gui/Window.cpp', 'ObservableCollection<', 'ObservableCollectionImproved<T>']
- samples:
  - sub_6EC064 -> CPhysical::helper_sub_6EC064 (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), CPhysical::Add(void), ay::obfuscated_data<71ull,14068102883376568763ull>::o..., CMatrix::UpdateRW(void))
  - sub_6EC388 -> std::streambuf::helper_for_std::streambuf::uflow_void_sub_6EC388 (0.74; called by std::streambuf::uflow(void))
  - sub_6EC42C -> CPhysical::helper_for_CPhysical::ProcessCollisionSectorList_CPtrList_sub_6EC42C (0.74; called by CPhysical::ProcessCollisionSectorList(CPtrList *))
  - sub_6ECF04 -> CPhysical::helper_for_CPhysical::RemoveAndAdd_void_sub_6ECF04 (0.74; called by CPhysical::RemoveAndAdd(void))
  - sub_6ED148 -> CPhysical::helper_for_CPhysical::RemoveAndAdd_void_sub_6ED148 (0.74; called by CPhysical::RemoveAndAdd(void))
  - sub_6EDDC8 -> ay::obfuscated_data<T>::helper_sub_6EDDC8 (0.66; calls __aarch64_ldadd4_rel)
  - sub_6EE678 -> CKeyBoard::helper_for_CKeyBoard::ChatHandler_char_const_sub_6EE678 (0.74; called by CKeyBoard::ChatHandler(char const*))
  - sub_6EE790 -> CKeyBoard::helper_for_CKeyBoard::ChatHandler_char_const_sub_6EE790 (0.74; called by CKeyBoard::ChatHandler(char const*))

### sub_FA4A2C..sub_10910E8 (2107 funcs)
- modules: [('Curl', 420), ('std::time_get_byname<char,std::istreambuf_iterator<T>>', 226), ('Gui::CMapModel', 189), ('thunk_to', 134), ('nghttp2', 80), ('Noesis::TypeOfHelperBase<T>', 60)]
- kinds: [('calls_known_cluster', 1248), ('string_reference', 628), ('thunk_to_known_function', 155), ('single_known_caller_helper', 76)]
- between: Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActionT<Noesis::Control>,NoesisApp::TriggerAction>::Create(Noesis::Symbol) -> std::moneypunct_byname<wchar_t,false>::do_pos_format(void)
- strings: ['Converter<', 'Boxed<', '../../../../../Native/Src/Packages/Gui/Core/Src/BaseCollection.cpp', '../../../../../Native/Src/Packages/Gui/Core/Src/BaseFreezableCollection.cpp', 'Collection', 'None', 'FillRule', 'KeyboardNavigationMode']
- samples:
  - sub_FA4A2C -> lookup::stringref_BaseBinding_sub_FA4A2C (0.58; string "BaseBinding")
  - sub_FA4BB8 -> lookup::stringref_Delay_sub_FA4BB8 (0.58; string "Delay")
  - sub_FA4CCC -> lookup::stringref_../../../../../Native/Src/Packages/Gui/Core/Src/BaseBinding.cpp_sub_FA4CCC (0.58; string "../../../../../Native/Src/Packages/Gui/Core/Src/BaseBinding.cpp")
  - sub_FA4DB4 -> Noesis::TypeOfHelperBase<T>::helper_sub_FA4DB4 (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(..., Noesis::ICommand::StaticGetClassType(Noesis::TypeTag<..., __aarch64_ldadd4_relax, Curl_infof)
  - sub_FA519C -> Noesis::TypeOfHelperBase<T>::helper_sub_FA519C (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(..., NoesisApp::MouseDragElementBehavior::SetX(float))
  - sub_FA550C -> Noesis::TypeOfHelperBase<T>::helper_sub_FA550C (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(..., NoesisApp::MouseDragElementBehavior::SetX(float))
  - sub_FA56F0 -> Noesis::TypeOfHelperBase<T>::helper_sub_FA56F0 (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(..., NoesisApp::MouseDragElementBehavior::SetX(float))
  - sub_FA57F4 -> Noesis::TypeOfHelperBase<T>::helper_sub_FA57F4 (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(..., NoesisApp::MouseDragElementBehavior::SetX(float))

### sub_99890C..sub_ABD1FC (1526 funcs)
- modules: [('ay::obfuscated_data<T>', 367), ('Noesis::TypePropertyFunction<T>', 95), ('Noesis', 79), ('Curl', 71), ('OUTLINED', 66), ('Gui::CHudModel', 58)]
- kinds: [('calls_known_cluster', 1072), ('string_reference', 185), ('single_known_caller_helper', 173), ('thunk_to_known_function', 96)]
- between: Noesis::XamlProvider::~XamlProvider() -> ay::obfuscated_data<31ull,9016711428731545553ull>::decrypt(void)
- strings: ['cannot use value() with ', 'Ptr<%s>', 'ObservableCollection<', 'Assertion failed!', 'ObservableCollectionImproved<T>', 'cannot use at() with ', "key '", 'cannot compare iterators of different containers']
- samples:
  - sub_99890C -> Noesis::TypePropertyFunction<T>::helper_sub_99890C (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::json_...)
  - sub_999DF4 -> Noesis::TypePropertyFunction<T>::helper_sub_999DF4 (0.66; calls CGame::Process(void), std::filebuf::close(void))
  - sub_99A174 -> Noesis::TypePropertyFunction<T>::helper_sub_99A174 (0.66; calls std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::detail::concat<std::strin..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::jso...)
  - sub_99A548 -> Noesis::TypePropertyFunction<T>::helper_sub_99A548 (0.66; calls std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::detail::concat<std::strin..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::jso...)
  - sub_99A91C -> Noesis::TypePropertyFunction<T>::helper_sub_99A91C (0.66; calls std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::detail::concat<std::strin..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::jso...)
  - sub_99AB18 -> Noesis::TypePropertyFunction<T>::helper_sub_99AB18 (0.66; calls eastl::basic_string<char,eastl::allocator>::assign(ch..., std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohman..., nlohmann::jso...)
  - sub_99B678 -> Noesis::TypePropertyFunction<T>::helper_sub_99B678 (0.66; calls nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohman..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., std::vector<nlohmann::json_abi_v3_11_2::basic_json<st.....)
  - sub_99B8D8 -> Noesis::TypePropertyFunction<T>::helper_sub_99B8D8 (0.66; calls std::underflow_error::~underflow_error(), nlohmann::json_abi_v3_11_2::detail::concat<std::strin..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::jso...)

### sub_12039A4..sub_127EA44 (1366 funcs)
- modules: [('Curl', 473), ('thunk_to', 51), ('mpg123', 30), ('mime', 27), ('eastl::prime_rehash_policy', 25), ('miniz', 24)]
- kinds: [('calls_known_cluster', 939), ('string_reference', 273), ('thunk_to_known_function', 144), ('single_known_caller_helper', 10)]
- between: miniz_def_realloc_func -> std::codecvt_byname<char16_t,char,mbstate_t>::~codecvt_byname()
- strings: ['Collection', '../../../../../Native/Src/Packages/Gui/Core/Src/BaseFreezableCollection.cpp', "Can't get item, index out of bounds", 'Converter<', 'SlipBehavior', 'FillBehavior', 'Value', 'Nullable<']
- samples:
  - sub_12039A4 -> Curl::helper_sub_12039A4 (0.66; calls Noesis::IdOf(char const*,char const*))
  - sub_1203C0C -> Curl::helper_sub_1203C0C (0.66; calls Noesis::IdOf(char const*,char const*))
  - sub_1203E74 -> Curl::helper_sub_1203E74 (0.66; calls Noesis::IdOf(char const*,char const*))
  - sub_1203FF4 -> Curl::helper_sub_1203FF4 (0.66; calls __aarch64_ldadd4_relax)
  - sub_120404C -> Curl::stringref_Converter_sub_120404C (0.58; string "Converter<")
  - sub_12040A8 -> Curl::stringref_Nullable_sub_12040A8 (0.58; string "Nullable<")
  - sub_12042D0 -> Curl::helper_sub_12042D0 (0.66; calls __aarch64_ldadd4_relax)
  - sub_1204328 -> Curl::stringref_Converter_sub_1204328 (0.58; string "Converter<")

### sub_1122238..sub_11D9B7C (1074 funcs)
- modules: [('Curl', 459), ('Gui::RadioDescriptionViewModel', 167), ('Noesis::TypePropertyFunction<T>', 125), ('thunk_to', 43), ('Noesis', 35), ('Noesis::TypeOfHelperBase<T>', 30)]
- kinds: [('calls_known_cluster', 692), ('string_reference', 248), ('single_known_caller_helper', 83), ('thunk_to_known_function', 51)]
- between: nghttp2_downcase -> Curl_strntolower
- strings: ['../../../../../Native/Src/Packages/Gui/Core/Src/ScrollHelper.cpp', 'Offset cannot be NaN', 'LayoutUpdated', '../../../../../Native/Src/Packages/Gui/Core/Src/BaseCollection.cpp', '../../../../../Native/Src/Packages/Gui/Core/Src/XamlNode.cpp', 'Visibility', 'Normal', 'ScrollBarVisibility']
- samples:
  - sub_1122238 -> Curl::helper_sub_1122238 (0.66; calls Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActio...)
  - sub_1122374 -> Curl::helper_sub_1122374 (0.66; calls Curl_cf_http_proxy_get_host, __aarch64_ldadd4_relax)
  - sub_1122904 -> Curl::helper_sub_1122904 (0.66; calls Curl_infof)
  - sub_1123484 -> Curl::stringref_BrushProxy_sub_1123484 (0.58; string "BrushProxy")
  - sub_1123738 -> Curl::helper_sub_1123738 (0.66; calls `non-virtual thunk to'NoesisApp::AttachableCollection...)
  - sub_11238FC -> `non-virtual thunk to'NoesisApp::AttachableCollection<T>::helper_for_non-virtual_thunk_to_NoesisApp::AttachableCollection_NoesisApp::_sub_11238FC (0.74; called by `non-virtual thunk to'NoesisApp::AttachableCollection<NoesisApp::TriggerBase>::GetNumReferenc...)
  - sub_1123930 -> Curl::helper_sub_1123930 (0.66; calls __aarch64_ldadd4_relax)
  - sub_1123A1C -> Curl::helper_sub_1123A1C (0.66; calls __aarch64_ldadd4_relax)

### sub_9030E0..sub_98D124 (890 funcs)
- modules: [('ay::obfuscated_data<T>', 277), ('Noesis::TypePropertyFunction<T>', 42), ('nlohmann::json_abi_v3_11_2::detail::iter_impl<nlohmann::json_abi_v3_11_2::basic_json<std::map,std::v', 36), ('OUTLINED', 29), ('eastl::internal::function_base_detail<T>::function_manager<Gui::RadioStreamWrapper', 21), ('Gui::CHudModel', 20)]
- kinds: [('calls_known_cluster', 601), ('single_known_caller_helper', 168), ('thunk_to_known_function', 67), ('string_reference', 54)]
- between: cf_he_connect -> std::filebuf::close(void)
- strings: ['cannot use value() with ', 'Ptr<%s>', 'ObservableCollection<', 'status', 'Assertion failed!', 'cannot compare iterators of different containers', 'ObservableCollectionImproved<T>', 'levelId']
- samples:
  - sub_9030E0 -> cf::helper_for_cf_he_connect_sub_9030E0 (0.74; called by cf_he_connect)
  - sub_9032A0 -> Gui::MapObjectViewModel::helper_sub_9032A0 (0.66; calls __aarch64_ldadd4_relax)
  - sub_9032E8 -> Gui::MapObjectViewModel::helper_sub_9032E8 (0.66; calls __aarch64_ldadd4_relax)
  - sub_9035C0 -> cf::helper_for_cf_he_connect_sub_9035C0 (0.74; called by cf_he_connect)
  - sub_903C04 -> Gui::MapObjectViewModel::helper_sub_903C04 (0.66; calls __aarch64_ldadd4_relax)
  - sub_903E98 -> cf::helper_for_cf_he_connect_sub_903E98 (0.74; called by cf_he_connect)
  - sub_904058 -> cf::helper_for_cf_he_connect_sub_904058 (0.74; called by cf_he_connect)
  - sub_90421C -> cf::helper_for_cf_he_connect_sub_90421C (0.74; called by cf_he_connect)

### sub_109C874..sub_10E7110 (603 funcs)
- modules: [('Gui::CMapModel', 402), ('Curl', 36), ('thunk_to', 30), ('Noesis::TypeOfHelperBase<T>', 17), ('Noesis::ICommand', 15), ('eastl::shared_ptr<util::Callback<T>>', 14)]
- kinds: [('calls_known_cluster', 451), ('string_reference', 106), ('thunk_to_known_function', 32), ('single_known_caller_helper', 14)]
- between: bufs_alloc_chain -> ay::obfuscated_data<19ull,4983698286846223833ull>::~obfuscated_data()
- strings: ['PenLineCap', 'Converter<ModifierKeys>', 'IsVisibleChanged', 'PenLineJoin', 'PointCollectionConverter', 'BrushMappingMode', 'MenuItemRole', 'MouseAction']
- samples:
  - sub_109C874 -> Gui::CMapModel::stringref_Converter_Key_sub_109C874 (0.58; string "Converter<Key>")
  - sub_109CADC -> Gui::CMapModel::stringref_KeyGesture_sub_109CADC (0.58; string "KeyGesture")
  - sub_109CC68 -> Gui::CMapModel::helper_sub_109CC68 (0.66; calls std::promise<void>::promise)
  - sub_109CD64 -> ::helper_sub_109CD64 (0.66; calls __aarch64_ldadd4_relax)
  - sub_109CED4 -> ::helper_sub_109CED4 (0.66; calls __aarch64_ldadd4_relax)
  - sub_109D044 -> Gui::CMapModel::stringref_Alt_sub_109D044 (0.58; string "Alt+")
  - sub_109D1E8 -> thunk_to::Noesis::DelegateImpl<bool ()(int,int)>::MultiDelegate::Remove(Noesis::Delegate<bool ()(int,int)> const&) (0.88; short wrapper calls Noesis::DelegateImpl<bool ()(int,int)>::MultiDelegate::Remove(Noesis::Delegate<bool ()(int,in...)
  - sub_109D204 -> ::helper_sub_109D204 (0.66; calls __aarch64_ldadd4_relax)

### sub_ED54F0..sub_F10BF8 (546 funcs)
- modules: [('Curl', 114), ('std::moneypunct<T>', 32), ("`non-virtual thunk to'std::time_get_byname<char,std::istreambuf_iterator<T>>", 27), ('Noesis::TypeOfHelperBase<T>', 24), ('libunwind::EHHeaderParser<T>', 15), ('thunk_to::Noesis', 14)]
- kinds: [('calls_known_cluster', 373), ('string_reference', 123), ('single_known_caller_helper', 25), ('thunk_to_known_function', 25)]
- between: `non-virtual thunk to'std::time_get_byname<char,std::istreambuf_iterator<char>>::__c(void) -> `non-virtual thunk to'NoesisApp::SetFocusAction::~SetFocusAction()
- strings: ['Converter<', 'Boxed<', 'Nullable<', '../../../../../Native/Src/Packages/Gui/DependencySystem/Src/DependencyObject.cpp', "Can't modify read-only property '%s.%s'", '%s %s', '../../../../../Native/Src/Packages/Gui/DependencySystem/Src/PropertyMetadata.cpp', "Can't modify PropertyMetadata, it is already in use"]
- samples:
  - sub_ED54F0 -> Gui::Backend::CNoesisBackend::helper_for_Gui::Backend::CNoesisBackend::_CNoesisBackend_sub_ED54F0 (0.74; called by Gui::Backend::CNoesisBackend::~CNoesisBackend())
  - sub_ED5BB8 -> libunwind::EHHeaderParser<T>::helper_sub_ED5BB8 (0.66; calls Curl_infof)
  - sub_ED5D88 -> libunwind::EHHeaderParser<T>::helper_sub_ED5D88 (0.66; calls Curl_infof)
  - sub_ED5EE0 -> libunwind::EHHeaderParser<T>::stringref_Category_sub_ED5EE0 (0.58; string "Category")
  - sub_ED6058 -> libunwind::EHHeaderParser<T>::stringref_Infinity_sub_ED6058 (0.58; string "Infinity")
  - sub_ED7580 -> libunwind::EHHeaderParser<T>::stringref_Type_sub_ED7580 (0.58; string "Type")
  - sub_ED77B0 -> ::helper_sub_ED77B0 (0.66; calls __aarch64_ldadd4_relax)
  - sub_ED798C -> libunwind::EHHeaderParser<T>::helper_sub_ED798C (0.66; calls Curl_infof)

### sub_8BB00C..sub_8F3238 (323 funcs)
- modules: [('ay::obfuscated_data<T>', 40), ('Noesis::TypePropertyFunction<T>', 26), ('Gui::CMapViewModel::helper_for_Gui::CMapViewModel', 24), ('Noesis', 18), ('Gui::CMapContent::helper_for_Gui::CMapContent::ConnectField_Noesis', 13), ('eastl::hashtable<Gui::EMapObjectGroupId,eastl::pair<T>,eastl::allocator,eastl::use_first<eastl::pair', 11)]
- kinds: [('single_known_caller_helper', 151), ('calls_known_cluster', 147), ('thunk_to_known_function', 13), ('string_reference', 12)]
- between: Gui::ApplyCategoriesPatch(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::allocator,n... -> _GLOBAL__sub_I_GuiStrings.cpp
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/gui/screens/Map/MapModel.cpp', 'ObservableCollection<', 'ObservableCollectionImproved<T>', 'Ptr<%s>', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/gui/screens/Map/MapContent.xaml.cpp', 'VisualProgress', '21MapScreenVisibleEvent']
- samples:
  - sub_8BB00C -> ::helper_for_GLOBAL__sub_I_MapConfig.cpp_sub_8BB00C (0.74; called by _GLOBAL__sub_I_MapConfig.cpp)
  - sub_8BB0DC -> ::helper_for_GLOBAL__sub_I_MapConfig.cpp_sub_8BB0DC (0.74; called by _GLOBAL__sub_I_MapConfig.cpp)
  - sub_8BB18C -> ::helper_for_GLOBAL__sub_I_MapConfig.cpp_sub_8BB18C (0.74; called by _GLOBAL__sub_I_MapConfig.cpp)
  - sub_8BB27C -> ::helper_for_GLOBAL__sub_I_MapConfig.cpp_sub_8BB27C (0.74; called by _GLOBAL__sub_I_MapConfig.cpp)
  - sub_8BB684 -> Gui::`anonymous namespace'::helper_for_Gui::_anonymous_namespace_::ReadColor_nlohmann::json_abi_v3_11_2_sub_8BB684 (0.74; called by Gui::`anonymous namespace'::ReadColor(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::ve...)
  - sub_8BB738 -> Gui::`anonymous namespace'::helper_for_Gui::_anonymous_namespace_::ReadColor_nlohmann::json_abi_v3_11_2_sub_8BB738 (0.74; called by Gui::`anonymous namespace'::ReadColor(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::ve...)
  - sub_8BBFD8 -> Gui::helper_for_Gui::ApplyInitialPatch_nlohmann::json_abi_v3_11_2::basic_json_st_sub_8BBFD8 (0.74; called by Gui::ApplyInitialPatch(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::strin...)
  - sub_8BC11C -> Gui::helper_for_Gui::ApplyInitialPatch_nlohmann::json_abi_v3_11_2::basic_json_st_sub_8BC11C (0.74; called by Gui::ApplyInitialPatch(nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::strin...)

### sub_C63654..sub_C8E8D0 (188 funcs)
- modules: [('std::__function::__func<firebase::crashlytics', 22), ('CJSONTransport', 20), ('ay::obfuscated_data<T>', 16), ('firebase::crashlytics::helper_for_firebase::crashlytics', 7), ('Java', 7), ('CCustomBuildingRenderer::helper_for_CCustomBuildingRenderer', 5)]
- kinds: [('single_known_caller_helper', 92), ('calls_known_cluster', 64), ('string_reference', 22), ('thunk_to_known_function', 10)]
- between: std::iostream::~basic_iostream() -> CTaskComplexInWater::CreateNextSubTask(CPed *)
- strings: ['materialName', 'terrain', 'Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/skel/android/HelpshiftBridge.cpp', 'ZN3cus17DownloadResourcesERKNSt6__ndk18functionIFvjRK10UICallbackEEERKNS1_IFvRK13ECUSystemC', 'u_pbrModelEmissionColorAlpha', 'u_pbrModelEmissionStrength', 'u_terrainTileMult']
- samples:
  - sub_C63654 -> CSpeedometerNumbers::helper_for_CSpeedometerNumbers::Draw_uint_uint_float_float_float_float_floa_sub_C63654 (0.74; called by CSpeedometerNumbers::Draw(uint,uint,float,float,float,float,float,bool,uchar))
  - sub_C63664 -> std::ostream::helper_for_std::ostream::operator_uint_sub_C63664 (0.74; called by std::ostream::operator<<(uint))
  - sub_C637B0 -> std::ostream::helper_for_std::ostream::operator_uint_sub_C637B0 (0.74; called by std::ostream::operator<<(uint))
  - sub_C637C0 -> CSpeedometerNumbers::helper_for_CSpeedometerNumbers::Draw_uint_uint_float_float_float_float_floa_sub_C637C0 (0.74; called by CSpeedometerNumbers::Draw(uint,uint,float,float,float,float,float,bool,uchar))
  - sub_C637FC -> std::ostream::helper_for_std::ostream::operator_uint_sub_C637FC (0.74; called by std::ostream::operator<<(uint))
  - sub_C63904 -> CShapeHelper::helper_for_CShapeHelper::DrawCircleSectorTextured_CShapeHelper::ShapeParame_sub_C63904 (0.74; called by CShapeHelper::DrawCircleSectorTextured(CShapeHelper::ShapeParameters,CRGBA,rw::Texture *))
  - sub_C641AC -> CShapeHelper::helper_for_CShapeHelper::DrawCircleSectorTextured_CShapeHelper::ShapeParame_sub_C641AC (0.74; called by CShapeHelper::DrawCircleSectorTextured(CShapeHelper::ShapeParameters,CRGBA,rw::Texture *))
  - sub_C64490 -> CShapeHelper::helper_for_CShapeHelper::DrawCircleSectorTextured_CShapeHelper::ShapeParame_sub_C64490 (0.74; called by CShapeHelper::DrawCircleSectorTextured(CShapeHelper::ShapeParameters,CRGBA,rw::Texture *))

### sub_681898..sub_6AF520 (141 funcs)
- modules: [('CGame::helper_for_CGame::ApplySettings_nlohmann::json_abi_v3_11_2', 21), ('ay::obfuscated_data<T>', 19), ('nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std', 15), ('CGame', 6), ('CFileLoader::helper_for_CFileLoader', 5), ('CFireManager', 4)]
- kinds: [('calls_known_cluster', 77), ('single_known_caller_helper', 63), ('thunk_to_known_function', 1)]
- between: myfopen(char const*,char const*) -> CRadar::GetActualBlipArrayIndex(int)
- strings: ['cannot use value() with ', 'Assertion failed!', 'isWinterEnabled', 'type must be number, but is ', 'vehicles', 'scale', 'Verify failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/templates.h']
- samples:
  - sub_681898 -> CFireManager::helper_sub_681898 (0.66; calls std::__fs::filesystem::detail::`anonymous namespace':...)
  - sub_6818F8 -> CFireManager::helper_sub_6818F8 (0.66; calls std::thread::detach(void))
  - sub_6819EC -> CFireManager::helper_sub_6819EC (0.66; calls std::__fs::filesystem::detail::`anonymous namespace':...)
  - sub_681AF4 -> CFireManager::helper_sub_681AF4 (0.66; calls eastl::hash_map<Gui::EScreenId,eastl::shared_ptr<Gui:..., ctpl::thread_pool::thread_pool(int), eastl::shared_ptr<util::CallbackHolder>::~shared_ptr(), ay::obfuscated_data<...)
  - sub_682458 -> ::helper_sub_682458 (0.66; calls eastl::shared_ptr<Keyboard::CInputHandler>::~shared_p...)
  - sub_6824C4 -> AppEventHandler::helper_for_AppEventHandler_sub_6824C4 (0.74; called by AppEventHandler)
  - sub_6831DC -> ::helper_sub_6831DC (0.66; calls std::__fs::filesystem::__file_size(std::__fs::filesys...)
  - sub_683334 -> ::helper_sub_683334 (0.66; calls Log::_P::ContextStack::Instance(void))

### sub_D75B68..sub_D9C3E4 (136 funcs)
- modules: [('Noesis::ValueStorageManagerImpl<Noesis::Ptr<T>>', 16), ('thunk_to', 13), ('ImGui', 11), ('Noesis', 11), ('NoesisApp::DataEventTrigger', 9), ('Noesis::EnumConverter<T>', 5)]
- kinds: [('calls_known_cluster', 75), ('single_known_caller_helper', 29), ('thunk_to_known_function', 28), ('string_reference', 4)]
- between: TableSettingsHandler_ReadLine(ImGuiContext *,ImGuiSettingsHandler *,void *,char const*) -> Noesis::DelegateImpl<void ()(Noesis::BaseComponent *,Noesis::PropertyChangedEventArgs const&)>::MultiDelegate::Copy(Noesis::DelegateImpl<...
- strings: ['Boxed<', 'ResourceKey', 'NoesisGUIExtensions.Loc', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/vendor/noesis-extensions/ApplicationLauncher/Src/LocExtension.cpp', "Resource key '%s' not found in Loc Resources", 'LocMonitor', 'Text', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/vendor/noesis-extensions/ApplicationLaun']
- samples:
  - sub_D75B68 -> ImGui::helper_for_ImGui::TableSettingsAddSettingsHandler_void_sub_D75B68 (0.74; called by ImGui::TableSettingsAddSettingsHandler(void))
  - sub_D78868 -> thunk_to::Noesis::TypeOf<NoesisApp::LineDecorationBehavior>(void) (0.88; short wrapper calls Noesis::TypeOf<NoesisApp::LineDecorationBehavior>(void))
  - sub_D78B48 -> ImGui::helper_sub_D78B48 (0.66; calls __aarch64_ldadd4_relax)
  - sub_D78BBC -> ImGui::helper_sub_D78BBC (0.66; calls Noesis::ValueStorageManagerImpl<Noesis::Ptr<NoesisApp..., __aarch64_ldadd4_relax)
  - sub_D78FFC -> ImGui::helper_sub_D78FFC (0.66; calls __aarch64_ldadd4_relax)
  - sub_D79130 -> ImGui::stringref_NoesisGUIExtensions.Loc_sub_D79130 (0.58; string "NoesisGUIExtensions.Loc")
  - sub_D7923C -> ImGui::helper_sub_D7923C (0.66; calls OUTLINED_FUNCTION_7_6, Noesis::Ptr<Noesis::PropertyMetadata>::~Ptr(), OUTLINED_FUNCTION_0_19, Noesis::DependencyData::RegisterProperty<Noesis::Uri>...)
  - sub_D797B8 -> ImGui::helper_sub_D797B8 (0.66; calls Noesis::DependencyObject::InternalCoerceValue<Noesis:...)

### sub_AE4F2C..sub_B11ED4 (126 funcs)
- modules: [('rw::helper_for_rw::readMaterialMatFX_rw', 13), ('CVehicleModelInfo', 10), ('CVehicleModelInfo::helper_for_CVehicleModelInfo', 10), ('CActorPool::helper_for_CActorPool', 7), ('std::__time_get_storage<T>::helper_for_std::__time_get_storage_char_', 6), ('CNetGame', 6)]
- kinds: [('single_known_caller_helper', 78), ('calls_known_cluster', 42), ('thunk_to_known_function', 6)]
- between: filterScanline(uchar *,uchar const*,uchar const*,ulong,ulong,uchar) -> CLocalPlayer::Process(void)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/minigames/drift_master/DriftMasterMinigame.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/modelinfo/VehicleModelInfo.cpp', 'normal', 'pbrNormal', 'Verify failed!', 'exhaust_stock', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/network/AsyncStreamingManager.cpp']
- samples:
  - sub_AE4F2C -> CLocalPlayer::helper_sub_AE4F2C (0.66; calls CLocalPlayer::GetPlayerKeys(void), Curl_http_proxy_create_CONNECT, eastl::rbtree<eastl::basic_string<char,eastl::allocat...)
  - sub_AE61F0 -> rw::MatFX::helper_sub_AE61F0 (0.66; calls rw::Texture::destroy(void))
  - sub_AE622C -> thunk_to::rw::Texture::destroy(void) (0.88; short wrapper calls rw::Texture::destroy(void))
  - sub_AE626C -> thunk_to::rw::Texture::destroy(void) (0.88; short wrapper calls rw::Texture::destroy(void))
  - sub_AE6F00 -> CCustomBuildingRenderer::helper_for_CCustomBuildingRenderer::AtomicSetup_rw::Atomic_short_sub_AE6F00 (0.74; called by CCustomBuildingRenderer::AtomicSetup(rw::Atomic *,short))
  - sub_AE7188 -> CCustomBuildingPipelineHeplper::helper_for_CCustomBuildingPipelineHeplper::RenderInstance_CustomBuildingPip_sub_AE7188 (0.74; called by CCustomBuildingPipelineHeplper::RenderInstance(CustomBuildingPipelineData::BuildingInst const&))
  - sub_AE7214 -> `anonymous namespace'::helper_for_anonymous_namespace_::SetAtomicSelected_rw::Atomic_void_sub_AE7214 (0.74; called by `anonymous namespace'::SetAtomicSelected(rw::Atomic *,void *))
  - sub_AE729C -> rw::MatFX::helper_sub_AE729C (0.66; calls cf_haproxy_destroy)

### sub_D9FB8C..sub_DC396C (120 funcs)
- modules: [('thunk_to::NoesisApp::TranslateZoomRotateBehavior', 19), ('thunk_to', 9), ('Noesis', 5), ('Noesis::ValueStorageManagerImpl<Noesis::Ptr<T>>', 4), ('Noesis::helper_for_Noesis::TypeOf_NoesisApp', 4), ('thunk_to::NoesisApp::StoryboardAction', 4)]
- kinds: [('thunk_to_known_function', 45), ('single_known_caller_helper', 39), ('calls_known_cluster', 34), ('string_reference', 2)]
- between: NoesisApp::Interaction::GetTriggers(Noesis::DependencyObject const*) -> mi_segment_cache_pop_ex
- strings: ['Collection', 'KeyDown', 'KeyUp', 'NoesisApp.LaunchUriOrFileAction', 'TriggerActionT', 'NoesisGUIExtensions.LineDecorationBehavior', 'NoesisApp.RemoveElementAction', 'NoesisGUIExtensions.SelectAction']
- samples:
  - sub_D9FB8C -> NoesisApp::Interaction::helper_for_NoesisApp::Interaction::StaticFillClassType_Noesis::TypeClassCre_sub_D9FB8C (0.74; called by NoesisApp::Interaction::StaticFillClassType(Noesis::TypeClassCreator &))
  - sub_D9FF18 -> NoesisApp::Interaction::helper_for_NoesisApp::Interaction::StaticFillClassType_Noesis::TypeClassCre_sub_D9FF18 (0.74; called by NoesisApp::Interaction::StaticFillClassType(Noesis::TypeClassCreator &))
  - sub_D9FF68 -> `non-virtual thunk to'Noesis::FreezableCollection<T>::helper_for_non-virtual_thunk_to_Noesis::FreezableCollection_NoesisApp::Trig_sub_D9FF68 (0.74; called by `non-virtual thunk to'Noesis::FreezableCollection<NoesisApp::TriggerAction>::~FreezableCollec...)
  - sub_DA06FC -> thunk_to::__aarch64_ldadd4_relax (0.88; short wrapper calls __aarch64_ldadd4_relax)
  - sub_DA07E8 -> Noesis::ValueStorageManagerImpl<Noesis::Ptr<T>>::helper_sub_DA07E8 (0.66; calls __aarch64_ldadd4_relax)
  - sub_DA08F4 -> thunk_to::__aarch64_ldadd4_relax (0.88; short wrapper calls __aarch64_ldadd4_relax)
  - sub_DA0ADC -> Noesis::ValueStorageManagerImpl<Noesis::Ptr<T>>::helper_sub_DA0ADC (0.66; calls __aarch64_ldadd4_relax)
  - sub_DA1088 -> thunk_to::NoesisApp::AttachableCollection<NoesisApp::TriggerAction>::StaticGetClassType(Noesis::TypeTag<NoesisApp::AttachableCo... (0.88; short wrapper calls NoesisApp::AttachableCollection<NoesisApp::TriggerAction>::StaticGetClassType(Noesis::TypeTag...)

### sub_11ED0D8..sub_120010C (110 funcs)
- modules: [('Curl', 103), ('thunk_to', 2), ('helper_sub_11ED998', 1), ('helper_sub_11EDB68', 1), ('helper_sub_11F0B58', 1), ('helper_sub_11F0D58', 1)]
- kinds: [('calls_known_cluster', 80), ('string_reference', 28), ('thunk_to_known_function', 2)]
- between: nghttp2_bufs_seek_last_present -> RakNet::BitStream::BitStream(int)
- strings: ['GridViewColumnHeaderRole', '/system/fonts', 'AllowsColumnReorder', 'ColumnHeaderContainerStyle', 'Visibility', 'HorizontalAlignment', 'version', 'encoding']
- samples:
  - sub_11ED0D8 -> Curl::stringref_version_sub_11ED0D8 (0.58; string "version")
  - sub_11ED998 -> ::helper_sub_11ED998 (0.66; calls __aarch64_ldadd4_relax)
  - sub_11ED9F0 -> Curl::stringref_XamlReaderProvider_sub_11ED9F0 (0.58; string "XamlReaderProvider")
  - sub_11EDB68 -> ::helper_sub_11EDB68 (0.66; calls __aarch64_ldadd4_relax)
  - sub_11EE68C -> Curl::stringref_component/_sub_11EE68C (0.58; string ";component/")
  - sub_11F0B58 -> ::helper_sub_11F0B58 (0.66; calls __aarch64_ldadd4_relax)
  - sub_11F0D58 -> ::helper_sub_11F0D58 (0.66; calls __aarch64_ldadd4_relax)
  - sub_11F0EB4 -> ::helper_sub_11F0EB4 (0.66; calls __aarch64_ldadd4_relax)

### sub_8F7958..sub_8FE354 (96 funcs)
- modules: [('ay::obfuscated_data<T>', 22), ('Gui::MapObjectViewModel', 11), ('nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std', 1), ('cf', 1), ('helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F7B68', 1), ('helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F7E8C', 1)]
- kinds: [('single_known_caller_helper', 61), ('string_reference', 21), ('calls_known_cluster', 14)]
- between: _GLOBAL__sub_I_GuiStrings.cpp -> cf_he_connect
- strings: ['Title', 'ImagePath', 'OpenTime', 'ButtonTitle', 'BlackRussia.SaleBannerVM', 'Sale', 'OldPrice', 'SubTitle']
- samples:
  - sub_8F7958 -> nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::::helper_sub_8F7958 (0.66; calls nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., CNetGame::GetGameState(void))
  - sub_8F7B58 -> cf::helper_for_cf_he_connect_sub_8F7B58 (0.74; called by cf_he_connect)
  - sub_8F7B68 -> ::helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F7B68 (0.74; called by _GLOBAL__sub_I_GuiStrings.cpp)
  - sub_8F7E8C -> ::helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F7E8C (0.74; called by _GLOBAL__sub_I_GuiStrings.cpp)
  - sub_8F8174 -> ::helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F8174 (0.74; called by _GLOBAL__sub_I_GuiStrings.cpp)
  - sub_8F8764 -> ::helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F8764 (0.74; called by _GLOBAL__sub_I_GuiStrings.cpp)
  - sub_8F8CEC -> ay::obfuscated_data<T>::helper_sub_8F8CEC (0.66; calls ay::obfuscated_data<27ull,8022544353138530575ull>::de...)
  - sub_8F9204 -> ::helper_for_GLOBAL__sub_I_GuiStrings.cpp_sub_8F9204 (0.74; called by _GLOBAL__sub_I_GuiStrings.cpp)

### sub_B80580..sub_B8F170 (85 funcs)
- modules: [('ScrCommonStuff', 16), ('CRemotePlayer::helper_for_CRemotePlayer', 14), ('WorldVehicleAdd', 11), ('ScrSetPlayerSkin', 7), ('WorldPlayerRemove', 4), ('ay::obfuscated_data<T>', 4)]
- kinds: [('single_known_caller_helper', 70), ('calls_known_cluster', 14), ('thunk_to_known_function', 1)]
- between: ScrCommonStuff(RPCParameters *) -> CNetTextDrawPool::New(ushort,TextDrawDataPacked const&,char *)
- strings: ['14ChatFlushEvent', '22HudElementVisibleEvent', '16ChatVisibleEvent', '19FireWaterLevelEvent', '18FireSuitLevelEvent', '18HudMenuButtonEvent', '14DailyCaseEvent', '20DailyCasePointsEvent']
- samples:
  - sub_B80580 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80580 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80654 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80654 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80B8C -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80B8C (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80C58 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80C58 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80CC4 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80CC4 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80E44 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80E44 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B80F20 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B80F20 (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_B810F0 -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_B810F0 (0.74; called by ScrCommonStuff(RPCParameters *))

### sub_CB241C..sub_CC3E3C (79 funcs)
- modules: [('CWidgetRegionMove', 6), ('ay::obfuscated_data<T>', 6), ('CWidget', 5), ("std::__fs::filesystem::detail::`anonymous namespace'::helper_for_std::__fs::filesystem::detail::_ano", 5), ('ay::obfuscated_data<T>::helper_for_ay::obfuscated_data_9ull_1996064099368389581ull_', 5), ('CTouchInterface', 3)]
- kinds: [('single_known_caller_helper', 45), ('calls_known_cluster', 28), ('thunk_to_known_function', 3), ('string_reference', 3)]
- between: CTouchInterface::IsPressed(TouchWidgetPrioritized::EId) -> Curl_wildcard_dtor
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/BuildConfig.cpp', 'touch_bar', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/FreezeMonitor.cpp', 'ZN11JsonStorageC1EvE3$_0', '%Y-%m-%d %H:%M:%S', '.%03lld ', "Logger: it's unable to use crashlytics logs before initialization!"]
- samples:
  - sub_CB241C -> CTouchInterface::helper_sub_CB241C (0.66; calls CHud::IsNewVersion(void))
  - sub_CB2A34 -> CTouchInterface::helper_sub_CB2A34 (0.66; calls __aarch64_ldadd4_relax)
  - sub_CB2A98 -> CTouchInterface::helper_sub_CB2A98 (0.66; calls CSpeedometer::CSpeedometer(void), __aarch64_ldadd4_relax, __aarch64_ldadd4_rel)
  - sub_CB41D4 -> ::helper_for_GLOBAL__sub_I_TouchInterface.cpp_sub_CB41D4 (0.74; called by _GLOBAL__sub_I_TouchInterface.cpp)
  - sub_CB42B4 -> ::helper_for_GLOBAL__sub_I_TouchInterface.cpp_sub_CB42B4 (0.74; called by _GLOBAL__sub_I_TouchInterface.cpp)
  - sub_CB4340 -> ::helper_for_GLOBAL__sub_I_TouchInterface.cpp_sub_CB4340 (0.74; called by _GLOBAL__sub_I_TouchInterface.cpp)
  - sub_CB43F4 -> ::helper_for_GLOBAL__sub_I_TouchInterface.cpp_sub_CB43F4 (0.74; called by _GLOBAL__sub_I_TouchInterface.cpp)
  - sub_CB440C -> ::helper_for_GLOBAL__sub_I_TouchInterface.cpp_sub_CB440C (0.74; called by _GLOBAL__sub_I_TouchInterface.cpp)

### sub_BEC464..sub_BFB6CC (77 funcs)
- modules: [('std::time_get<wchar_t,std::istreambuf_iterator<T>>', 23), ('CPlayerPed', 8), ('CMatrix', 8), ('std::__fs::filesystem::path::helper_for_std::__fs::filesystem::path', 6), ('ay::obfuscated_data<T>', 5), ('CPed::helper_for_CPed', 3)]
- kinds: [('calls_known_cluster', 54), ('single_known_caller_helper', 21), ('thunk_to_known_function', 2)]
- between: CPlayerPed::CanEnterCar(void) -> CChat::Initialise(void)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/peds/WeaponManager.cpp', 'cannot use value() with ', 'Verify failed!', 'Fatal error!', 'invalid simplex', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/templates.h']
- samples:
  - sub_BEC464 -> CPlayerPed::helper_sub_BEC464 (0.66; calls __aarch64_cas4_relax, __aarch64_ldadd4_relax, __aarch64_ldadd4_rel)
  - sub_BEC708 -> CPlayerPed::helper_sub_BEC708 (0.66; calls eastl::hash_map<Gui::EScreenId,eastl::shared_ptr<Gui:...)
  - sub_BEC924 -> CPlayerPed::helper_sub_BEC924 (0.66; calls Curl_hsts_save, __aarch64_ldadd4_rel)
  - sub_BEC9F0 -> CPlayerPed::helper_sub_BEC9F0 (0.66; calls nlohmann::json_abi_v3_11_2::basic_json<std::map,std::..., CFileMgr::ReadLine(int,char *,int), util::Delegate<>::invoke(void), std::__fs::filesystem::path::lexically_normal...)
  - sub_BED4D4 -> std::__fs::filesystem::path::helper_for_std::__fs::filesystem::path::__filename_void_sub_BED4D4 (0.74; called by std::__fs::filesystem::path::__filename(void))
  - sub_BED6D4 -> std::__fs::filesystem::path::helper_for_std::__fs::filesystem::path::lexically_normal_void_sub_BED6D4 (0.74; called by std::__fs::filesystem::path::lexically_normal(void))
  - sub_BEDCC4 -> CPlayerPed::helper_sub_BEDCC4 (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), Log::_P::ContextStack::Instance(void), __cxa_guard_acquire)
  - sub_BEE064 -> CPed::helper_for_CPed::CPed_uint_sub_BEE064 (0.74; called by CPed::CPed(uint))

### sub_AC16D0..sub_AC86B4 (72 funcs)
- modules: [('rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue', 58), ('rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::AddCommand_rw::gl3', 2), ('rw::gl3::helper_for_rw::gl3', 2), ('CWeapon::helper_for_CWeapon', 2), ('rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::StartReading_uint_::__0', 2), ('CZIPFileSystem::helper_for_CZIPFileSystem::CZIPFileSystem_void_::__11', 2)]
- kinds: [('single_known_caller_helper', 71), ('calls_known_cluster', 1)]
- between: rw::gl3::CRenderQueue::AddCommand(rw::gl3::eRQCommands) -> CdStreamInitThread(void)::$_1::operator()(void)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/librw/gl/gl3renderqueue.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/librw/gl/gl3renderqueue.h', 'Verify failed!']
- samples:
  - sub_AC16D0 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::AddCommand_rw::gl3::eRQCommands_sub_AC16D0 (0.74; called by rw::gl3::CRenderQueue::AddCommand(rw::gl3::eRQCommands))
  - sub_AC178C -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::AddCommand_rw::gl3::eRQCommands_sub_AC178C (0.74; called by rw::gl3::CRenderQueue::AddCommand(rw::gl3::eRQCommands))
  - sub_AC19D8 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::EndReading_void_sub_AC19D8 (0.74; called by rw::gl3::CRenderQueue::EndReading(void))
  - sub_AC1A94 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::EndReading_void_sub_AC1A94 (0.74; called by rw::gl3::CRenderQueue::EndReading(void))
  - sub_AC1B14 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::ProcessCommands_void_sub_AC1B14 (0.74; called by rw::gl3::CRenderQueue::ProcessCommands(void))
  - sub_AC1BE0 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::ProcessCommands_void_sub_AC1BE0 (0.74; called by rw::gl3::CRenderQueue::ProcessCommands(void))
  - sub_AC1EB4 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::AddUint32_uint_sub_AC1EB4 (0.74; called by rw::gl3::CRenderQueue::AddUint32(uint))
  - sub_AC22E4 -> rw::gl3::CRenderQueue::helper_for_rw::gl3::CRenderQueue::AddU32Args_uint_..._sub_AC22E4 (0.74; called by rw::gl3::CRenderQueue::AddU32Args(uint,...))

### sub_10EBE5C..sub_10F6A0C (68 funcs)
- modules: [('Gui::CMapModel', 56), ('thunk_to', 5), ('Curl', 3), ('thunk_to::Noesis', 1), ('Gui::CHudViewModel::helper_for_Gui::CHudViewModel::StaticGetClassType_Noesis::TypeTag_Gui', 1), ('nghttp2', 1)]
- kinds: [('calls_known_cluster', 48), ('string_reference', 13), ('thunk_to_known_function', 6), ('single_known_caller_helper', 1)]
- between: Noesis::DelegateImpl<bool ()(Noesis::BaseComponent *)>::FunctorStub<Gui::CMapViewModel::CMapViewModel(void)::$_3>::Equal(Noesis::Delegate... -> Curl_cf_http_proxy_get_host
- strings: ['RadiusX', '../../../../../Native/Src/Packages/Gui/Core/Src/PropertyPathConverter.cpp', "Unknown prefix '%s'", 'Converter<PropertyPath>', 'Q%g,%g %g,%g', 'QuadraticBezierSegment', 'Point1', 'Point2']
- samples:
  - sub_10EBE5C -> thunk_to::Noesis::DelegateImpl<bool ()(int,int)>::MultiDelegate::Remove(Noesis::Delegate<bool ()(int,int)> const&) (0.88; short wrapper calls Noesis::DelegateImpl<bool ()(int,int)>::MultiDelegate::Remove(Noesis::Delegate<bool ()(int,in...)
  - sub_10EBE78 -> Gui::CMapModel::helper_sub_10EBE78 (0.66; calls __aarch64_ldadd4_relax)
  - sub_10EC298 -> thunk_to::__aarch64_ldadd4_relax (0.88; short wrapper calls __aarch64_ldadd4_relax)
  - sub_10EC2B4 -> Gui::CMapModel::helper_sub_10EC2B4 (0.66; calls __aarch64_ldadd4_relax)
  - sub_10EC320 -> thunk_to::__aarch64_ldadd4_relax (0.88; short wrapper calls __aarch64_ldadd4_relax)
  - sub_10EC33C -> Gui::CMapModel::helper_sub_10EC33C (0.66; calls __aarch64_ldadd4_relax)
  - sub_10EC384 -> Gui::CMapModel::stringref_Converter_PropertyPath_sub_10EC384 (0.58; string "Converter<PropertyPath>")
  - sub_10EC50C -> Gui::CMapModel::helper_sub_10EC50C (0.66; calls __aarch64_ldadd4_relax)

### sub_6CC83C..sub_6E2A6C (66 funcs)
- modules: [('CWorld::helper_for_CWorld', 7), ('CEntity::helper_for_CEntity', 6), ('ay::obfuscated_data<T>', 5), ('Storage::CZipDirectoryIterator', 3), ('AppEventHandler', 3), ('CEntity::helper_for_CEntity::Add_void_::__1', 3)]
- kinds: [('single_known_caller_helper', 46), ('calls_known_cluster', 16), ('thunk_to_known_function', 4)]
- between: CWorld::Process(void) -> CPhysical::ApplyMoveSpeed(void)
- strings: ['Assertion failed!', '15OnEntityDeleted', 'vector', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/templates.h', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Dummy.cpp', 'Verify failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Entity.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Entity.h']
- samples:
  - sub_6CC83C -> CWorld::helper_for_CWorld::Process_void_sub_6CC83C (0.74; called by CWorld::Process(void))
  - sub_6CD824 -> CWorld::helper_for_CWorld::ProcessLineOfSightSectorList_CPtrList_CColLine_const_CCo_sub_6CD824 (0.74; called by CWorld::ProcessLineOfSightSectorList(CPtrList &,CColLine const&,CColPoint &,float &,CEntity *...)
  - sub_6CE000 -> CWorld::helper_for_CWorld::Process_void_sub_6CE000 (0.74; called by CWorld::Process(void))
  - sub_6CE290 -> CRenderer::helper_for_CRenderer::SortBIGBuildings_void_sub_6CE290 (0.74; called by CRenderer::SortBIGBuildings(void))
  - sub_6CE5FC -> Storage::CZipStorage::helper_for_Storage::CZipStorage::Open_char_const_::__1::operator_void_sub_6CE5FC (0.74; called by Storage::CZipStorage::Open(char const*)::$_1::operator()(void))
  - sub_6CE838 -> CWorld::helper_for_CWorld::Process_void_sub_6CE838 (0.74; called by CWorld::Process(void))
  - sub_6CE854 -> CWorld::helper_for_CWorld::Process_void_sub_6CE854 (0.74; called by CWorld::Process(void))
  - sub_6CE88C -> CWorld::helper_for_CWorld::Process_void_sub_6CE88C (0.74; called by CWorld::Process(void))

### sub_BFE964..sub_C0D8E4 (63 funcs)
- modules: [('CEntityPreview::helper_for_CEntityPreview', 36), ('nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::', 4), ('CCoronas', 2), ('CCollision::helper_for_CCollision', 2), ('CEntityPreview::helper_for_CEntityPreview::CreatePlateSnapShot_EntityPreviewParams_const_', 2), ('CEntityPreview::helper_for_CEntityPreview::ValidateTexture_rw::Texture_::__0', 2)]
- kinds: [('single_known_caller_helper', 57), ('calls_known_cluster', 6)]
- between: CChat::Draw(void) -> CWeaponEffects::ClearCrossHair(void)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/renderer/EntityPreview.cpp']
- samples:
  - sub_BFE964 -> CChat::helper_for_CChat::Draw_void_sub_BFE964 (0.74; called by CChat::Draw(void))
  - sub_C00454 -> nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::::helper_for_nlohmann::json_abi_v3_11_2::basic_... (0.74; called by nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,doubl...)
  - sub_C00720 -> nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::::helper_for_nlohmann::json_abi_v3_11_2::basic_... (0.74; called by nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,doubl...)
  - sub_C007BC -> nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::::helper_for_nlohmann::json_abi_v3_11_2::basic_... (0.74; called by nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,doubl...)
  - sub_C007C8 -> CEntityPreview::helper_for_CEntityPreview::CreatePedSnapShot_EntityPreviewParams_const_::___sub_C007C8 (0.74; called by CEntityPreview::CreatePedSnapShot(EntityPreviewParams const&)::$_0::operator()(void))
  - sub_C00914 -> nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,double,std::::helper_for_nlohmann::json_abi_v3_11_2::basic_... (0.74; called by nlohmann::json_abi_v3_11_2::basic_json<std::map,std::vector,std::string,bool,long,ulong,doubl...)
  - sub_C00A98 -> rw::Texture::helper_sub_C00A98 (0.66; calls rw::Texture::destroy(void))
  - sub_C01540 -> CAutomobile::helper_for_CAutomobile::SetStrobes_bool_eStrobesMode_sub_C01540 (0.74; called by CAutomobile::SetStrobes(bool,eStrobesMode))

### sub_C93174..sub_CA4144 (61 funcs)
- modules: [('CTaskSimpleSwim', 8), ('CTextureDatabase::helper_for_CTextureDatabase', 7), ('CTextureDatabase::helper_for_CTextureDatabase::UpdateRaster_rw', 4), ('CWidgetButtonMeleeAimGun::helper_for_CWidgetButtonMeleeAimGun', 4), ('CTextureDatabaseRuntime::helper_for_CTextureDatabaseRuntime', 3), ('CWidgetButton', 3)]
- kinds: [('single_known_caller_helper', 30), ('calls_known_cluster', 25), ('thunk_to_known_function', 6)]
- between: CTaskSimpleSwim::Clone(void) -> CTouchInterface::GetRawWidget(TouchWidgetPrioritized::EId)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/tasks/TaskTypes/TaskSimpleUseTablet.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Entity.h', 'btn_up', 'btn_down']
- samples:
  - sub_C93174 -> CTaskSimpleSwim::helper_sub_C93174 (0.66; calls CTaskSimple::CTaskSimple(void))
  - sub_C931B4 -> CTaskSimpleSwim::helper_sub_C931B4 (0.66; calls CAnimBlendAssociation::SetDeleteCallback(void (*)(CAn..., CPed::SetCurrentWeapon(eWeaponType), CPed::RemoveWeaponModel(uint))
  - sub_C93248 -> CPad::helper_for_CPad::StartShake_Distance_short_uchar_float_float_float_sub_C93248 (0.74; called by CPad::StartShake_Distance(short,uchar,float,float,float))
  - sub_C932E0 -> CTaskSimpleSwim::helper_sub_C932E0 (0.66; calls Log::_P::ContextStack::Instance(void), __cxa_guard_acquire)
  - sub_C934E0 -> CPed::helper_sub_C934E0 (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), CAnimBlendAssociation::SetFinishCallback(void (*)(CAn..., CAnimBlendAssociation::SetDeleteCallback(void (*)(CAn...,...)
  - sub_C93978 -> CAnimManager::helper_sub_C93978 (0.66; calls CAnimBlendAssociation::SetFinishCallback(void (*)(CAn..., CAnimManager::GetAnimationBlock(char const*), CAnimManager::GetAnimationBlockIndex(char const*), CAnimManager::Ad...)
  - sub_C93C0C -> CTaskSimpleSwim::helper_sub_C93C0C (0.66; calls CPed::AddWeaponModel(uint), Log::_P::ContextStack::Instance(void))
  - sub_C93DD4 -> CTaskSimpleSwim::helper_sub_C93DD4 (0.66; calls General::GetRandomNumberInRange(float,float))

### sub_B927CC..sub_B9D734 (56 funcs)
- modules: [('CNetTextDrawPool::helper_for_CNetTextDrawPool', 13), ('CNetVehiclePool::helper_for_CNetVehiclePool', 8), ('CResponseHandle', 5), ('ay::obfuscated_data<T>', 4), ('CObject', 4), ('thunk_to::CResponseHandle', 3)]
- kinds: [('single_known_caller_helper', 34), ('calls_known_cluster', 18), ('thunk_to_known_function', 4)]
- between: ay::obfuscated_data<24ull,9200042382163167677ull>::~obfuscated_data() -> CObject::ManageObjects(void)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/network/requests/HttpApi.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/network/requests/JsonLocalCache.cpp', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/util/templates.h', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Entity.h']
- samples:
  - sub_B927CC -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B927CC (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B9296C -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B9296C (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B92B30 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B92B30 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B92B44 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B92B44 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B92E90 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B92E90 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B92FD4 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B92FD4 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B93138 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B93138 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))
  - sub_B93220 -> CNetTextDrawPool::helper_for_CNetTextDrawPool::DrawGamesPanel_void_sub_B93220 (0.74; called by CNetTextDrawPool::DrawGamesPanel(void))

### sub_B6B564..sub_B7BE38 (53 funcs)
- modules: [('CNetObjectPool::helper_for_CNetObjectPool', 17), ('RakNet::BitStream', 10), ('CNetObjectPool', 9), ('CNetVehiclePool::helper_for_CNetVehiclePool', 2), ('CPickupPool::helper_for_CPickupPool', 2), ('CPlayerPool', 2)]
- kinds: [('single_known_caller_helper', 27), ('calls_known_cluster', 26)]
- between: ay::obfuscated_data<41ull,10188037022078988781ull>::decrypt(void) -> UpdateScoresPingsIPs(RPCParameters *)
- strings: ["Can't find model ID %u for object", '16WantedLevelEvent', 'Invalid model ID %u for object', 'file: /home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/network/RPCs.cpp line: 315']
- samples:
  - sub_B6B564 -> eastl::hash_map<Gui::EScreenId,eastl::shared_ptr<T>,eastl::hash<T>,eastl::equal_to<T>,eastl::allocat::helper_sub_B6B564 (0.66; calls eastl::hash_map<Gui::EScreenId,eastl::shared_ptr<Gui:...)
  - sub_B6BE64 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6BE64 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6BEA0 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6BEA0 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6BF60 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6BF60 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6C020 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6C020 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6C0E0 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6C0E0 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6C264 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6C264 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))
  - sub_B6C380 -> CNetObjectPool::helper_for_CNetObjectPool::New_ushort_int_CVector_CVector_float_sub_B6C380 (0.74; called by CNetObjectPool::New(ushort,int,CVector,CVector,float))

### sub_F923C0..sub_F9C118 (51 funcs)
- modules: [("`non-virtual thunk to'NoesisApp::SetFocusAction", 8), ('Curl', 6), ('Noesis', 3), ('NoesisApp::BackgroundEffectBehavior', 2), ('Noesis::TypeOfHelperBase<T>', 2), ('Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActionT<T>,NoesisApp::TriggerAction>::helper_for_Noe', 1)]
- kinds: [('calls_known_cluster', 35), ('string_reference', 12), ('single_known_caller_helper', 4)]
- between: ay::obfuscated_data<6ull,4887432527069541209ull>::operator char *(void) -> Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActionT<Noesis::Control>,NoesisApp::TriggerAction>::Create(Noesis::Symbol)
- strings: ['SweepDirection', '../../../../../Native/Src/Packages/Gui/Core/Src/BaseBinding.cpp', "Can't modify a sealed Binding", 'Adorner', 'AdornedElement', 'IsClipEnabled', 'AdornerLayer', 'AdornerDecorator']
- samples:
  - sub_F923C0 -> Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActionT<T>,NoesisApp::TriggerAction>::helper_for_Noesis::TypeClassCreatorEmpty_NoesisApp::TriggerAc... (0.74; called by Noesis::TypeClassCreatorEmpty<NoesisApp::TriggerActionT<Noesis::Control>,NoesisApp::TriggerAc...)
  - sub_F924B8 -> ::helper_sub_F924B8 (0.66; calls __aarch64_cas8_acq_rel, __aarch64_ldadd4_acq_rel)
  - sub_F94FC8 -> ::helper_sub_F94FC8 (0.66; calls __aarch64_ldadd4_relax)
  - sub_F95630 -> ::helper_sub_F95630 (0.66; calls __aarch64_ldadd4_relax)
  - sub_F96198 -> NoesisApp::BackgroundEffectBehavior::stringref_../../../../../Native/Src/Packages/Gui/Core/Src/BaseBinding.cpp_sub_F96198 (0.58; string "../../../../../Native/Src/Packages/Gui/Core/Src/BaseBinding.cpp")
  - sub_F96374 -> Curl::helper_sub_F96374 (0.66; calls Curl_infof)
  - sub_F96524 -> Noesis::TypeClassCreatorEmpty<T>::helper_for_Noesis::TypeClassCreatorEmpty_anonymous_namespace_::EffectAdorne_sub_F96524 (0.74; called by Noesis::TypeClassCreatorEmpty<`anonymous namespace'::EffectAdorner,Noesis::Adorner>::Fill(Noe...)
  - sub_F966B0 -> Noesis::TypeOfHelperBase<T>::helper_sub_F966B0 (0.66; calls Noesis::TypeOfHelperBase<bool,Noesis::TypeMeta>::Get(...)

### sub_B630AC..sub_B6797C (49 funcs)
- modules: [('ScrCustomizeVehicle', 22), ('ay::obfuscated_data<T>', 5), ('ScrCommonStuff', 5), ('CNetVehiclePool::helper_for_CNetVehiclePool', 3), ('CNetGame::helper_for_CNetGame', 2), ('Curl', 2)]
- kinds: [('single_known_caller_helper', 41), ('calls_known_cluster', 8)]
- between: ay::obfuscated_data<41ull,222214999434416615ull>::decrypt(void) -> ftp_epsv_disable
- samples:
  - sub_B630AC -> CNetGame::helper_for_CNetGame::Packet_ConnectionSucceeded_Packet_sub_B630AC (0.74; called by CNetGame::Packet_ConnectionSucceeded(Packet *))
  - sub_B631FC -> CNetVehiclePool::helper_for_CNetVehiclePool::Process_void_sub_B631FC (0.74; called by CNetVehiclePool::Process(void))
  - sub_B63218 -> CNetVehiclePool::helper_for_CNetVehiclePool::New_NewVehiclePacked_const_sub_B63218 (0.74; called by CNetVehiclePool::New(NewVehiclePacked const&))
  - sub_B633E4 -> ay::obfuscated_data<T>::helper_sub_B633E4 (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), eastl::basic_string<char,eastl::allocator>::assign(ch..., cAudioManager::PlayOneShot(int,ushort,float), cDMAudio::G...)
  - sub_B655A4 -> CNetVehiclePool::helper_for_CNetVehiclePool::Process_void_sub_B655A4 (0.74; called by CNetVehiclePool::Process(void))
  - sub_B657E4 -> ay::obfuscated_data<T>::helper_sub_B657E4 (0.66; calls Log::_P::ContextStack::Instance(void))
  - sub_B65B50 -> ScrAttachTrailerToVehicle::helper_for_ScrAttachTrailerToVehicle_RPCParameters_sub_B65B50 (0.74; called by ScrAttachTrailerToVehicle(RPCParameters *))
  - sub_B65BC4 -> CNetGame::helper_for_CNetGame::Packet_Turnlights_Packet_sub_B65BC4 (0.74; called by CNetGame::Packet_Turnlights(Packet *))

### sub_C215EC..sub_C28B6C (46 funcs)
- modules: [('thunk_to::rw::Texture', 25), ('COcclusion', 7), ('Keyboard::CForwardInputHandler::helper_for_Keyboard::CForwardInputHandler::KeyUp_Keyboard', 4), ('CKeyBoard::helper_for_CKeyBoard', 4), ('CKeyBoard', 2), ('std::wstring_convert<std::helper_for_std::wstring_convert_std::codecvt_utf8_char32_t_1114111ul_std', 1)]
- kinds: [('thunk_to_known_function', 26), ('calls_known_cluster', 11), ('single_known_caller_helper', 9)]
- between: CKeyBoard::InitNUM(void) -> CParticle::Initialise(void)
- samples:
  - sub_C215EC -> CKeyBoard::helper_sub_C215EC (0.66; calls __aarch64_ldadd4_rel)
  - sub_C21664 -> CKeyBoard::helper_sub_C21664 (0.66; calls __aarch64_ldadd4_rel)
  - sub_C229C8 -> Keyboard::CForwardInputHandler::helper_for_Keyboard::CForwardInputHandler::KeyUp_Keyboard::kbKey_const_int_sub_C229C8 (0.74; called by Keyboard::CForwardInputHandler::KeyUp(Keyboard::kbKey const*,int))
  - sub_C22AA4 -> Keyboard::CForwardInputHandler::helper_for_Keyboard::CForwardInputHandler::KeyUp_Keyboard::kbKey_const_int_sub_C22AA4 (0.74; called by Keyboard::CForwardInputHandler::KeyUp(Keyboard::kbKey const*,int))
  - sub_C22C98 -> CKeyBoard::helper_for_CKeyBoard::Send_void_sub_C22C98 (0.74; called by CKeyBoard::Send(void))
  - sub_C233D0 -> CKeyBoard::helper_for_CKeyBoard::DeleteCharFromInput_void_sub_C233D0 (0.74; called by CKeyBoard::DeleteCharFromInput(void))
  - sub_C23B8C -> std::wstring_convert<std::helper_for_std::wstring_convert_std::codecvt_utf8_char32_t_1114111ul_std::c_sub_C23B8C (0.74; called by std::wstring_convert<std::codecvt_utf8<char32_t,1114111ul,(std::codecvt_mode)0>,char32_t,std:...)
  - sub_C23C38 -> Keyboard::CForwardInputHandler::helper_for_Keyboard::CForwardInputHandler::KeyUp_Keyboard::kbKey_const_int_sub_C23C38 (0.74; called by Keyboard::CForwardInputHandler::KeyUp(Keyboard::kbKey const*,int))

### sub_BB84CC..sub_BBF800 (41 funcs)
- modules: [('CPed::helper_for_CPed', 10), ('tftp', 10), ('CPed', 8), ('rw::Raster::helper_for_rw::Raster', 4), ('ProcessImGuiInput', 2), ('CPlayerInfo::helper_for_CPlayerInfo', 1)]
- kinds: [('single_known_caller_helper', 30), ('calls_known_cluster', 8), ('thunk_to_known_function', 3)]
- between: CPed::ProcessAttachedObjects(void) -> CPed::SetObjectiveTimer(int)
- strings: ['Assertion failed!', '/home/gitlab-runner/builds/Er1CC3zWB/0/client/BRClient/src/entities/Entity.h']
- samples:
  - sub_BB84CC -> CPed::helper_for_CPed::FightHitPed_CPed_CVector_CVector_short_sub_BB84CC (0.74; called by CPed::FightHitPed(CPed*,CVector &,CVector &,short))
  - sub_BBA4B4 -> CPed::helper_sub_BBA4B4 (0.66; calls CWorld::Add(CEntity *), CWorld::Remove(CEntity *), CMatrix::UpdateRW(void), CLocalPlayer::GetPlayerPed(void))
  - sub_BBA5DC -> CPlayerInfo::helper_for_CPlayerInfo::Process_void_sub_BBA5DC (0.74; called by CPlayerInfo::Process(void))
  - sub_BBC0AC -> ScrCommonStuff::helper_for_ScrCommonStuff_RPCParameters_sub_BBC0AC (0.74; called by ScrCommonStuff(RPCParameters *))
  - sub_BBC5CC -> CPed::helper_sub_BBC5CC (0.66; calls __cxa_guard_acquire)
  - sub_BBCF50 -> CPlayerPed::helper_for_CPlayerPed::RunningLand_CPad_sub_BBCF50 (0.74; called by CPlayerPed::RunningLand(CPad *))
  - sub_BBD368 -> thunk_to::CPedIntelligence::GetTaskSwim(void) (0.88; short wrapper calls CPedIntelligence::GetTaskSwim(void))
  - sub_BBD46C -> CPed::helper_sub_BBD46C (0.66; calls Log::_P::Context::Message(Log::ELevel,char const*,...), CLocalPlayer::GetPlayerPed(void), CPlayerPool::GetLocalPlayer(void), ProcessImGuiInput(void))
