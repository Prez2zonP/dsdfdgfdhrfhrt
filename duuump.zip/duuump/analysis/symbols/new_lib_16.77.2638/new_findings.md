﻿# br64 16.77.2638: краткий итог по новым/оставшимся функциям

## Что было обработано

- Известная карта переноса: `addres_16.77.2638.txt`, 15181 функция.
- Индекс новой либы:
  - C/Hex-Rays: 59183 функции.
  - ASM/IDA: 61576 функций.
  - общий union-индекс: 62611 адресов.
- Дополнительно размечено/предположено: 47430 функций, которых нет в старой карте.

## Сильный слой предположений

Файл: `strong_inferred.txt`

- 12378 строк с более сильными основаниями, чем просто соседство по адресу.
- Внутри:
  - thunk/wrapper к известной функции: 1115.
  - helper, вызываемый одной известной функцией: 2780.
  - функция вызывает известный кластер: 8483.

## Все предположения

Файл: `remaining_inferred.txt`

- 47430 строк.
- Формат: `sub_... -> suggested_name ; confidence=...; kind=...; evidence=...`
- Слабый слой `address_neighborhood` оставлен специально: это не точное имя, а полезная навигационная метка по ближайшим известным функциям.

## Реально видимые новые имена в дампе

Файл: `actual_named_extra.txt`

Hex-Rays/IDA сохранила 204 читаемых имени, которых не было в старой карте. Самые заметные зоны:

- `Java_com_blackhub_bronline_game_core_JNIConfig_*` около `sub_642C7C..sub_643390`.
  - native config tree: `nativeGetChild`, `nativeGetIntPacked`, `nativeGetFloat`, `nativeGetString`, `nativeSetInt`, `nativeSetFloat`, `nativeSetString`, `nativeGameSettings`.
- `Java_com_blackhub_bronline_game_core_keyboardHelper_SoftwareKeyboardBridge_*` около `sub_7460C8..sub_74667C`.
  - native обработка soft keyboard: key up/down, commit text, visibility, keyboard size.
- `Java_com_blackhub_bronline_launcher_di_HelpshiftManager_nativeInit` at `sub_C74430`.
- `Java_com_blackhub_bronline_game_core_JNILib_*` около `sub_C74B80..sub_C8BA78`.
  - `sendJsonData`, `sendUpdateSystemCodedMessage`, `tryGetPatchIndex`, `getAdditionDownloadPatchData`, `tryDownloadResources`, `tryDownloadNextSlot`, `getCurrentPatchVersion`, `getTargetPatchVersion`, `start`, `orientationChanged`, `cancelDownloadResources_0`.
- Большой блок `mz_*` около `sub_DCC71C..sub_DD538C`.
  - miniz/zip streams, raw/os/zlib/pkcrypt streams, zip entry read/write, path/os helpers.
- `zng_*` около `sub_EBD6F0..sub_ECA5D0`.
  - zlib-ng: crc32, deflate init/deflate, inflate init/inflate.

## Похоже на новое по логике

- Добавлен/сильно расширен native config bridge (`JNIConfig`) для чтения/записи настроек.
- Появился отдельный native bridge для Android software keyboard.
- Появился/вынесен Helspift native init.
- Update/patch/resource download заметно расширен: patch index, current/target patch version, next slot/resources download.
- Внутри новой либы виден полноценный miniz + zlib-ng стек, включая zip write/read и pkcrypt. Это похоже на новую или расширенную систему упаковки/патчей/ресурсов.
- Много новых Noesis/Gui binding/helper функций, особенно вокруг `CMapModel`, `CMapViewModel`, `CHudModel`, `RadioDescriptionViewModel`.
- Много Curl/cf/nghttp2 окружения, судя по вызовам и соседству: вероятно расширенный HTTP/2/network слой.

## Осторожность

- `actual_named_extra` можно считать наиболее надежным: имя прямо видно в новом дампе.
- `strong_inferred` полезен для навигации и ренейма, но это эвристика.
- `remaining_inferred` содержит и слабые метки по соседству, их лучше использовать как подсказки, а не как окончательные имена.

