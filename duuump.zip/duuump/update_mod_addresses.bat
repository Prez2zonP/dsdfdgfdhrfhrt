@echo off
setlocal
set "ROOT=%~dp0..\.."
cd /d "%ROOT%"

if "%~1"=="" (
  py -3 "%ROOT%\tools\update_mod_addresses.py" --apply
) else (
  if "%~2"=="" (
    echo Usage: update_mod_addresses.bat OLD_LIB_DIR NEW_LIB_DIR
    echo Example: update_mod_addresses.bat game\library-game\br-16.78.3341 game\library-game\br-16.78.3400
    pause
    exit /b 1
  )
  py -3 "%ROOT%\tools\update_mod_addresses.py" --old-dir "%~1" --new-dir "%~2" --apply
)

echo.
echo Done. Report: analysis\addresses\address_update_report.txt
pause
